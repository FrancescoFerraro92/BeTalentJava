package it.begear.corso.interfacceEastratte;

public abstract class Forma {

	public abstract double area();
	
}
