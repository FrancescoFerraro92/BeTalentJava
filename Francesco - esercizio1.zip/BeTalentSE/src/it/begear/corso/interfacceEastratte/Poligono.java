package it.begear.corso.interfacceEastratte;

public abstract class Poligono extends Forma {
	
	public abstract double perimetro();

}
