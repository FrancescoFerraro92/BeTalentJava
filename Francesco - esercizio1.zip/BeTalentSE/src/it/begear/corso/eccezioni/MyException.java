package it.begear.corso.eccezioni;

public class MyException extends Exception {
	
	public String getMessage() {
		return "� stato inserito un valore nullo!";
	}
	
}