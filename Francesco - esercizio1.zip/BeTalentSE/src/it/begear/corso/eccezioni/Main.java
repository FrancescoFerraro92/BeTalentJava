package it.begear.corso.eccezioni;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Main {
	
//Dichiarazione dell'eccezione (declaring)
	public static void main (String[] args) throws MyException  {	
			
//Eccezione non gestita
		int[] array = new int[3];
//		array[245] = 5;

//Lancio di una eccezione personale
		String prova = null;
		if (prova == null) throw new MyException();
//		System.out.println(prova);

//Gestione dell'eccezione (handling)
		try {
			prova.equals("tucano");
			System.out.println(array[23456]);
			System.out.println("Sono qui");
		} catch (ArrayIndexOutOfBoundsException e){
			System.out.println("Array fuori dai limiti!");
		} catch (Exception e){
			System.out.println("Errore rilevato!");
		}
		finally {
			System.out.println("Dentro il finally");
		}
		
	}
	
	private static void printFile() throws IOException {

	    try(FileInputStream input = new FileInputStream("file.txt"); 
	    		BufferedInputStream bufferedInput = new BufferedInputStream(input)) {

		//---codice---
	      
	     } catch (Exception e) {}
	}
	
}
