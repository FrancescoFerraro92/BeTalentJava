package it.begear.corso.prova;

public class Animale {
	
	static boolean respira = true;
	String nome;
	boolean peloso;
	int et�;
	
	public Animale() {}

	public Animale(String nome, int et�) {
		super();
		this.nome = nome;
		this.et� = et�;
	}

	public String verso() {
		return "verso";
	}

//	@Override
//	public String toString() {
//		return "Animale [nome=" + nome + ", peloso=" + peloso + ", et�=" + et� + "]";
//	}
	
}
