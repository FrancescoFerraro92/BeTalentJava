package it.begear.corso.prova;

public class Utente {
	
	private String nome;
	private String cognome;
	private int et�;
	char pino;
	
	public Utente() {}
	
	public Utente(String nome, String cognome, int et�) {
		setNome(nome);
		setCognome(cognome);
		setEt�(et�);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public int getEt�() {
		return et�;
	}
	public void setEt�(int et�) {
		this.et� = et�;
	}
	
	public int somma(int a, int b) {
		return a+b;
	}

}
