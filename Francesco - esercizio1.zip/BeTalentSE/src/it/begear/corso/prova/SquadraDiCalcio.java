package it.begear.corso.prova;

public class SquadraDiCalcio {
	
	String nome;
	final int COMPONENTI = 22;
	String coloreMaglietta;
	int numeroTifosi;
	boolean championsLeague;
	
	public void modulo() {
		System.out.println("Modulo attuale: 4-3-3");
	}
	
	public int somma(int a, int b) {
		int risultato = a+b;
		return risultato;
	}

	@Override
	public String toString() {
		return "SquadraDiCalcio [nome=" + nome + ", COMPONENTI=" + COMPONENTI + ", coloreMaglietta=" + coloreMaglietta
				+ ", numeroTifosi=" + numeroTifosi + ", championsLeague=" + championsLeague + "]";
	}

}
