package it.begear.corso.prova;

import java.util.ArrayList;
import java.util.Arrays;

public class Prova2 {

}

//int rand = (int)(Math.random() * range) + min;
