package it.begear.corso.prova;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Prova {
	
	public static void main(String[] args) {
		
		SquadraDiCalcio squadra1 = new SquadraDiCalcio();
		squadra1.nome = "Napoli";
		squadra1.coloreMaglietta = "Azzurro";
		
		System.out.println("La squadra si chiama " + squadra1.nome + ", il colore della sua maglietta � " + squadra1.coloreMaglietta + ".");
		
		System.out.println(squadra1.toString());
		System.out.println("Nome della squadra: " + squadra1.nome);
		
		squadra1.modulo();
		
		int viv = 50;
		int zippo = 5;
		
		System.out.println("somma: " + squadra1.somma(viv, zippo));
		
		Animale animale1 = new Animale();
		animale1.nome = "Alma";
		animale1.peloso = true;
		animale1.et� = 8;
		
		System.out.println(animale1);
		
		int[] uno = {1, 2, 3};
		String[] due = {"uno", "cinque", "sei"};
		
		System.out.println(Arrays.toString(uno));
	
		for (String item : due) {
			for (int i=0; i<=due.length; i++) {
				if (item.equals(due[i])) {
					System.out.println("continuo a ciclare");
					continue;}
				System.out.println("Sto uscendo dal ciclo interno");
				break;
			}
		
		}
		
	}

}