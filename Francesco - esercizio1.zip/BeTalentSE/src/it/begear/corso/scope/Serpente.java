package it.begear.corso.scope;

public class Serpente {

	static final int LUNGHEZZA_MASSIMA = 5;
	static String mutazione;
	int length;

	public void grow(int inches) {
		if (length < LUNGHEZZA_MASSIMA) {
			int newSize = length + inches;
			length = newSize;
		}
	}
}

