package it.begear.corso.IO.fileReaderEwriter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Buffer{
	
	//FileInputStream e FileOutputStream sono da utilizzare per i file

public static void main(String[] args) throws IOException{

	BufferedReader in = null;
	PrintWriter out = null;

	try (FileInputStream fileIn = new FileInputStream("resources/index.jsp");
			FileOutputStream fileOut = new FileOutputStream("resources/bufferedIndex.jsp")){
		byte[] buffer = new byte[4096];  //Determino la dimensione del buffer
		int byteLetti;
		while((byteLetti = fileIn.read(buffer)) >= 0) {
			//Scrivimi i dati che sono dentro a 'byteLetti' nel buffer a partire 
			//dall'inizio del buffer, cio� zero
			fileOut.write(buffer, 0, byteLetti);
			}
		
		} catch (Exception e) {}
	
	in = new BufferedReader(new FileReader("resources/Testo.txt"));
	//PrintWriter gestisce anche primitivi, ma in questo caso una stringa
	out = new PrintWriter(new FileWriter("resources/TestoNuovo.txt"));
	String datoLetto;
	
	while ((datoLetto = in.readLine()) != null){
		//out.write(datoLetto);
		out.println(datoLetto); //Serve ad andare a capo. Non confondersi con il syso!!
		System.out.println(datoLetto);
	}
	
	in.close();
	out.close();
	
	{
			
	}

	}

}
