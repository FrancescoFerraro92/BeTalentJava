package it.begear.corso.IO.fileReaderEwriter;

public class Prova {
	
	public static void main(String[] args) {
		System.out.print("ciao sto per andare a capo\ninfatti � successo");
		
	}

}
