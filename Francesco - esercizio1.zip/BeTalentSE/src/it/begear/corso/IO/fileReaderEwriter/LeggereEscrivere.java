package it.begear.corso.IO.fileReaderEwriter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class LeggereEscrivere {

	public static void main (String[] args) {
		
	try {
		// Lista dei file dentro una directory
		File dir = new File("resources/");
		leggiFile(dir);
		
		//Creazione dello stream di input (piazza il tubo)
		//Indicazione del file di partenza (prima cisterna)
		FileReader reader = new FileReader("resources/Testo.txt");
		//Creazione dello stream di output (piazza il tubo)
		//Indicazione del file di arrivo (seconda cisterna)
		FileWriter writer = new FileWriter("resources/TestoCopiato.txt");
		int datoLetto;
	do {
		// lettura dei caratteri (apre le valvole)
		datoLetto = reader.read();
		if (datoLetto != -1) {
			// casta l�intero a char
			char c = (char) datoLetto;
			//scrittura dei caratteri
			writer.write(c);
			System.out.print(c);
		}
	} while (datoLetto != -1); // Fino alla fine del file
		// Chiusura dello stream (chiude le valvole)
		reader.close();
		// Esegue il flush
		writer.close();
	} catch (IOException e) {
		System.out.println(" ERRORE di I/O");
		System.out.println(e);
		}
	}
	
	public static void leggiFile(final File dir) {
		try {
		FileWriter writer = new FileWriter("resources/ListaFile.txt");
	    for (final File fileEntry : dir.listFiles()) {
	        if (fileEntry.isDirectory()) {
	        	leggiFile(fileEntry);
	        	writer.write("nome dir: " + fileEntry.getName() + "\n");
	        } else {
	            System.out.println(fileEntry.getName());
	            writer.write("nome file: " + fileEntry.getName() + "\n");
	        }
	    }writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

