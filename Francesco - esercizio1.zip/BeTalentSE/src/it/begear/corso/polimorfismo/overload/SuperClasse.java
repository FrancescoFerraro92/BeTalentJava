package it.begear.corso.polimorfismo.overload;

public class SuperClasse {
	
	int somma(int a, int b) {
		return a + b;
	}

}
