package it.begear.corso.polimorfismo.dati.esempioPratico;

public class Automobile extends Veicolo{
	
	public void accelera() {
		System.out.println("L'auto accelera");
	}
	
	public void decelera() {
		System.out.println("L'auto decelera");
	}
	
	public void retromarcia() {
		System.out.println("L'auto innesta la retromarcia");
	}

}
