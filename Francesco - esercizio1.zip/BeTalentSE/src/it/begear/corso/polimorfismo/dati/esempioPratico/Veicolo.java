package it.begear.corso.polimorfismo.dati.esempioPratico;

public class Veicolo {
	
	public void accelera() {
		System.out.println("il veicolo accelera");
	}
	
	public void decelera() {
		System.out.println("il veicolo decelera");
	}
	
	public void stoppaVeicolo() {
		System.out.println("Il veicolo si � fermato");
	}

}
