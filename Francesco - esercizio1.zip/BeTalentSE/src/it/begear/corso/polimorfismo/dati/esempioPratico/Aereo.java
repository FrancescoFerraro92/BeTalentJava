package it.begear.corso.polimorfismo.dati.esempioPratico;

public class Aereo extends Veicolo {
	
	public void accelera() {
		System.out.println("L'aereo accelera");
	}
	
	public void decelera() {
		System.out.println("L'aereo decelera");
	}
	
	public void decolla() {
		System.out.println("L'aereo decolla");
	}
	
	public void atterra() {
		System.out.println("L'aereo atterra");
	}

}
