package it.begear.corso.polimorfismo.override;

public class Gatto extends Animale{
	
	public void verso() {
		System.out.println("Miao");
	}

}
