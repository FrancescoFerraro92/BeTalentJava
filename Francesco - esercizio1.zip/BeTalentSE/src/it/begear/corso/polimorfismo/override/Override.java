package it.begear.corso.polimorfismo.override;

import java.util.Date;

public class Override {
	
	public static void main(String[] args) {
		
		Animale anim = new Animale();
		anim.verso();
		
		Gatto cat1 = new Gatto();
		cat1.verso();
		
		Object obj = new Date();

	    String s1 = obj.toString();
	    
	    System.out.println(s1);
		
	}

}
