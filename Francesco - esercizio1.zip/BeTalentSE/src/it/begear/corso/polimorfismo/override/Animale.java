package it.begear.corso.polimorfismo.override;

public class Animale {
	
	public void verso() {
		System.out.println("Un animale fa un verso");
	}

}