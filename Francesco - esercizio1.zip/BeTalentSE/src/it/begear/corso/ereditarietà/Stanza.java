package it.begear.corso.ereditariet�;

public class Stanza {

	private double metratura;
	private boolean luce;
	
	public Stanza(double metratura, boolean luce) {
		setMetratura(metratura);
		setLuce(luce);
	}

	public double getMetratura() {
		return metratura;
	}

	public void setMetratura(double metratura) {
		if (metratura < 4) System.out.println("La metratura � troppo piccola!");
		else this.metratura = metratura;
	}

	public boolean isLuce() {
		return luce;
	}

	public void setLuce(boolean luce) {
		this.luce = luce;
	}
	
	public Stanza() {}

	@Override
	public String toString() {
		return "Stanza [metratura=" + metratura + ", luce=" + luce + "]";
	}

}
