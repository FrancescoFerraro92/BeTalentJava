package it.begear.corso.generics.bibliotecaG;

public class Fantascienza extends Libro {

	public Fantascienza(String titolo, String autore) {
		super(titolo, autore);

	}

}
