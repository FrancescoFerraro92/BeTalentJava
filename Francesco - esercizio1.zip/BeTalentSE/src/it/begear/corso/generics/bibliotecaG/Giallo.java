package it.begear.corso.generics.bibliotecaG;

public class Giallo extends Libro{

	public Giallo(String titolo, String autore) {
		super(titolo, autore);
	}

}
