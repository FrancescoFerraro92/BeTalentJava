package it.begear.corso.generics.macero;

public class Mozzarella extends Cibo{
	
	public String toString() {
		return "mozzarelle";
	}

}
