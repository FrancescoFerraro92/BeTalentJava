package it.begear.corso.generics.macero;

public class Cibo {

}
