package it.begear.corso.generics.macero;

public class Cereale extends Cibo {
	
	public String toString() {
		return "cereali";
	}

}