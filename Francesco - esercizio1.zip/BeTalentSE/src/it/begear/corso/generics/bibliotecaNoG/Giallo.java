package it.begear.corso.generics.bibliotecaNoG;

public class Giallo extends Libro{

	public Giallo(String titolo, String autore) {
		super(titolo, autore);
	}

}
