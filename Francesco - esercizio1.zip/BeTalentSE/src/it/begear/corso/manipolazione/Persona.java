package it.begear.corso.manipolazione;

import java.lang.*;

public class Persona {

	int et�;
	int longevit�;
	String nome;

	public static int somma(int fattore1, int fattore2) {
		int c = fattore1+fattore2;
		return c;
	}

	public static void stampa(String a) {
		System.out.println(a);
	}

	public static void main(String[] args) {

		//Immutabilit� delle stringhe
		
		String stringa1;
		stringa1 = "a";
		stringa1 = "  Pino  ";
		stringa1.trim();
		System.out.println("Stringa non mutata: "+ stringa1);
		stringa1 = stringa1.trim();
		System.out.println("Stringa mutata: " + stringa1);

		byte numeroByte = 12;
		short numeroShort = 1234;
		int numeroIntero = 23563;
		long numeroLong = 5435243L;
		float numeroFloat = 0.333f;
		double numeroDouble = 0.455;

		int intero2 = (int) 234.56;
		System.out.println("Valore castato: " + intero2);

		byte byte1 = 12;
		byte byte2 = 13;

		byte somma = (byte) (byte1+byte2);

		boolean stato = true;

		char lettera = 'd';
		char simbolo = '*';
		char unicode = 225;
		System.out.println("Unicode: " + unicode);

		int a = 10;
		int b = 4;
		
		int tern = a<b ? 126 : 328;
		System.out.println("Ternario: " + tern);

		String titolo = "Batman";
		String titolo2 = "abracadabra";
		
		System.out.println("Uppercase: " + titolo);
		
		String txt = "Hello World";
	    System.out.println(txt.toUpperCase());
	    System.out.println(txt.toLowerCase());
		
		String trim = titolo.trim();
		System.out.println("Trim: " + trim);

		String replace = titolo.replace('a', 'u');
		System.out.println("Replace: " + replace);

		boolean bool = titolo.equals(titolo2);
		System.out.println("Uguaglianza :" + titolo.equals(titolo2));

		String risultato = titolo.substring(2,5);
		System.out.println("Substring: " + risultato);

		System.out.println(titolo2);
		stampa(titolo2);
		int risultatoSomma = somma(a, b);
		System.out.println("Risulato: " + risultatoSomma);

		//System.out.println(titolo);

		int c = a % b;

		System.out.println(c);
		System.out.println(a);
		System.out.println(b);

		//boolean risultato = titolo instanceof String;
		System.out.println(risultato);

	}

}
