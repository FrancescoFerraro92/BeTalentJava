package it.begear.corso.plimorfismo.dati;

import java.util.Date;

public class Main {
	
	public static void main (String[] args) {
		
	 //Collezione eterogenea	
	 //Object[] arr = {new Base(),"Hello World!",new Date()};
	
	Base base = new DerivedA();
	
	System.out.println("base � una istanza di DerivedA? " + (base instanceof DerivedA));
	System.out.println("base � una istanza di Base? " + (base instanceof Base));

	base.stampa();
	((DerivedA) base).primaVolta();
	
	DerivedA derivedA = new DerivedA();
	
	derivedA.stampa();
	
	DerivedA derivedB = new DerivedB();
	
	derivedB.stampa();
	
	}

}
