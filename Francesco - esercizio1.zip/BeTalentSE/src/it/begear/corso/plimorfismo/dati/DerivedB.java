package it.begear.corso.plimorfismo.dati;

public class DerivedB extends DerivedA{
	
	public void stampa() {
		System.out.println("Derived B");
	}

}
