package it.begear.corso.plimorfismo.dati;

public class Base {
	
	public void stampa() {
		System.out.println("Base");
	}

}